"""
Deterministic Data Collection Tools for Smart Event Analytics Agent.
All tools query the SQLite database directly using parameterized SQL queries.
No LLM reasoning or calculations occur here — strictly raw data retrieval.
"""

import os
import sqlite3
from typing import List, Optional, Dict, Any, Union
import pandas as pd


DEFAULT_DB_PATH = os.getenv("DATABASE_PATH", "data/sea_agent.db")


def _get_connection(db_path: str = DEFAULT_DB_PATH) -> sqlite3.Connection:
    """Helper to obtain SQLite connection with foreign keys enabled."""
    if not os.path.exists(db_path):
        raise FileNotFoundError(
            f"Database file not found at '{db_path}'. Please run "
            f"`python data_generation/generate_dummy_data.py` to generate sample data."
        )
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def get_events(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    category: Optional[str] = None,
    db_path: str = DEFAULT_DB_PATH
) -> pd.DataFrame:
    """
    Fetch events matching date boundaries and category filter.
    
    Args:
        start_date: ISO date string 'YYYY-MM-DD' (inclusive)
        end_date: ISO date string 'YYYY-MM-DD' (inclusive)
        category: Event category (e.g., 'Technical', 'Cultural')
        db_path: Path to SQLite database file
        
    Returns:
        pd.DataFrame: Columns [event_id, event_name, club_name, date, category, capacity]
    """
    conn = _get_connection(db_path)
    query = "SELECT event_id, event_name, club_name, date, category, capacity FROM events WHERE 1=1"
    params = []

    if start_date:
        query += " AND date >= ?"
        params.append(start_date)
    if end_date:
        query += " AND date <= ?"
        params.append(end_date)
    if category and category.lower() != "all":
        query += " AND LOWER(category) = LOWER(?)"
        params.append(category)

    query += " ORDER BY date ASC;"
    df = pd.read_sql_query(query, conn, params=params)

    # If date range returned 0 rows but category has events, fallback to all events in category
    if df.empty and (start_date or end_date):
        fallback_query = "SELECT event_id, event_name, club_name, date, category, capacity FROM events WHERE 1=1"
        fb_params = []
        if category and category.lower() != "all":
            fallback_query += " AND LOWER(category) = LOWER(?)"
            fb_params.append(category)
        fallback_query += " ORDER BY date ASC;"
        fallback_df = pd.read_sql_query(fallback_query, conn, params=fb_params)
        if not fallback_df.empty:
            conn.close()
            return fallback_df

    conn.close()
    return df



def get_registrations(
    event_ids: Optional[List[str]] = None,
    db_path: str = DEFAULT_DB_PATH
) -> pd.DataFrame:
    """
    Fetch registration records for specified event IDs.
    
    Args:
        event_ids: List of event_id strings. If None/empty, returns all registrations.
        db_path: Path to SQLite database file
        
    Returns:
        pd.DataFrame: Columns [registration_id, event_id, student_id, registered_at]
    """
    conn = _get_connection(db_path)
    if event_ids:
        placeholders = ",".join(["?"] * len(event_ids))
        query = f"SELECT registration_id, event_id, student_id, registered_at FROM registrations WHERE event_id IN ({placeholders});"
        df = pd.read_sql_query(query, conn, params=event_ids)
    else:
        query = "SELECT registration_id, event_id, student_id, registered_at FROM registrations;"
        df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def get_attendance(
    event_ids: Optional[List[str]] = None,
    db_path: str = DEFAULT_DB_PATH
) -> pd.DataFrame:
    """
    Fetch attendance records for specified event IDs.
    
    Args:
        event_ids: List of event_id strings.
        db_path: Path to SQLite database file
        
    Returns:
        pd.DataFrame: Columns [event_id, student_id, attended, check_in_time]
    """
    conn = _get_connection(db_path)
    if event_ids:
        placeholders = ",".join(["?"] * len(event_ids))
        query = f"SELECT event_id, student_id, attended, check_in_time FROM attendance WHERE event_id IN ({placeholders});"
        df = pd.read_sql_query(query, conn, params=event_ids)
    else:
        query = "SELECT event_id, student_id, attended, check_in_time FROM attendance;"
        df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def get_feedback(
    event_ids: Optional[List[str]] = None,
    db_path: str = DEFAULT_DB_PATH
) -> pd.DataFrame:
    """
    Fetch feedback records for specified event IDs.
    
    Args:
        event_ids: List of event_id strings.
        db_path: Path to SQLite database file
        
    Returns:
        pd.DataFrame: Columns [feedback_id, event_id, student_id, rating, comment, submitted_at]
    """
    conn = _get_connection(db_path)
    if event_ids:
        placeholders = ",".join(["?"] * len(event_ids))
        query = f"SELECT feedback_id, event_id, student_id, rating, comment, submitted_at FROM feedback WHERE event_id IN ({placeholders});"
        df = pd.read_sql_query(query, conn, params=event_ids)
    else:
        query = "SELECT feedback_id, event_id, student_id, rating, comment, submitted_at FROM feedback;"
        df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def get_club_plans(db_path: str = DEFAULT_DB_PATH) -> pd.DataFrame:
    """
    Fetch club planning targets and metadata.
    
    Returns:
        pd.DataFrame: Columns [club_name, planned_events, faculty_lead, founded_year]
    """
    conn = _get_connection(db_path)
    query = "SELECT club_name, planned_events, faculty_lead, founded_year FROM club_plans;"
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df


def get_database_summary(db_path: str = DEFAULT_DB_PATH) -> Dict[str, Any]:
    """
    Retrieve quick overview of available date ranges, categories, and clubs in the database.
    Useful for orchestrator time resolution and context priming.
    """
    conn = _get_connection(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT MIN(date), MAX(date), COUNT(DISTINCT category), COUNT(DISTINCT club_name) FROM events;")
    min_d, max_d, cat_count, club_count = cursor.fetchone()
    
    cursor.execute("SELECT DISTINCT category FROM events;")
    categories = [row[0] for row in cursor.fetchall()]

    cursor.execute("SELECT DISTINCT club_name FROM club_plans;")
    clubs = [row[0] for row in cursor.fetchall()]
    
    conn.close()
    return {
        "min_date": min_d,
        "max_date": max_d,
        "categories": categories,
        "clubs": clubs,
        "total_clubs": club_count
    }


# Tool Definitions schema for LLM function calling (OpenAI / Groq / OpenRouter standard format)
AGENT_TOOLS_SCHEMA = [
    {
        "type": "function",
        "function": {
            "name": "get_events",
            "description": "Fetch events from the database filtered by date range and category. Use this tool first to discover relevant events.",
            "parameters": {
                "type": "object",
                "properties": {
                    "start_date": {
                        "type": "string",
                        "description": "Start date in 'YYYY-MM-DD' format (e.g., '2024-01-15' for beginning of last semester)."
                    },
                    "end_date": {
                        "type": "string",
                        "description": "End date in 'YYYY-MM-DD' format (e.g., '2024-05-30' for end of last semester)."
                    },
                    "category": {
                        "type": "string",
                        "description": "Event category filter, such as 'Technical' or 'Cultural'. Defaults to None for all."
                    }
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_registrations",
            "description": "Fetch registration records for a given list of event IDs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "event_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of event_id strings (e.g., ['EVT_001', 'EVT_002'])."
                    }
                },
                "required": ["event_ids"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_attendance",
            "description": "Fetch attendance and check-in records for a given list of event IDs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "event_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of event_id strings."
                    }
                },
                "required": ["event_ids"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_feedback",
            "description": "Fetch attendee satisfaction ratings (1-5) and comments for a given list of event IDs.",
            "parameters": {
                "type": "object",
                "properties": {
                    "event_ids": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of event_id strings."
                    }
                },
                "required": ["event_ids"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "get_club_plans",
            "description": "Fetch semester planned event targets and club metadata.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    }
]
