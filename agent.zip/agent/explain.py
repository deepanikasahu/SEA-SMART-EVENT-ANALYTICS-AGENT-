"""
LLM Reasoning Layer and Grounding Validation for Smart Event Analytics Agent.
The LLM receives ONLY the pre-computed aggregate metrics JSON (no raw rows, no student PII).
Every numerical claim in the generated text is programmatically validated against the input table.
"""

import json
import re
from typing import Dict, List, Any, Tuple, Optional
from agent.llm_client import BaseLLMAdapter, get_llm_adapter


EXPLANATION_SYSTEM_PROMPT = """You are the Senior Analytics Reasoning Specialist for a university event management board.
Your task is to write a concise, professional executive narrative explaining the ranking of student clubs.

CRITICAL CONSTRAINTS (STRICT GROUNDING RULES):
1. You are given a PRE-COMPUTED metrics table as structured JSON.
2. You must NEVER calculate, estimate, or invent any numbers.
3. Every number, percentage, or rating you mention MUST be copied EXACTLY from the provided JSON table.
4. Do NOT cite any club name or metric not present in the JSON.
5. Highlight the Top 3 performing clubs: their primary strengths, attendance turnout, and participant feedback.
6. Explicitly mention any data integrity notes (e.g., partial data, missing attendance sheets) if present in the data_status.
7. Explain the performance tradeoffs (e.g., high engagement quality vs lower consistency).
8. Keep your response structured using markdown headings, bullet points, and bold club names.
"""


def extract_numbers_from_text(text: str) -> List[float]:
    """
    Extract all numeric values (integers, floats, percentages) from a text string.
    Filters out common non-metric tokens like markdown bullet indices.
    """
    # Regex matches decimals, percentages, and integers
    pattern = r'(?<![A-Za-z_])(\d+(?:\.\d+)?%?)(?![A-Za-z_])'
    matches = re.findall(pattern, text)
    numbers = []
    
    for m in matches:
        clean_m = m.replace("%", "").strip()
        try:
            val = float(clean_m)
            numbers.append(val)
        except ValueError:
            continue
            
    return numbers


def build_allowed_number_set(
    metrics_summary: List[Dict[str, Any]],
    weights_config: Optional[Dict[str, Any]] = None
) -> set:
    """
    Build a comprehensive set of allowed ground-truth numbers from the computed metrics table.
    Includes raw numbers, rounded variants, percentages, and safe contextual constants (e.g. 100, 5, 2024).
    """
    allowed = set()

    # Standard safe context constants (scale bounds, ranks 1-10, calendar days 1-31, years 2020-2030)
    safe_constants = {0.0, 50.0, 100.0}
    safe_constants.update(float(i) for i in range(1, 32))  # Days and ranks 1-31
    safe_constants.update(float(y) for y in range(2020, 2031))  # Calendar years
    allowed.update(safe_constants)


    if weights_config and "weights" in weights_config:
        for w in weights_config["weights"].values():
            allowed.add(float(w))
            allowed.add(round(float(w) * 100, 1))

    for row in metrics_summary:
        for key, val in row.items():
            if isinstance(val, (int, float)) and val is not None:
                f_val = float(val)
                allowed.add(round(f_val, 2))
                allowed.add(round(f_val, 1))
                allowed.add(round(f_val, 0))
                # For rates between 0 and 1, add the 100x percentage equivalent
                if 0.0 <= f_val <= 1.0:
                    pct = round(f_val * 100, 1)
                    allowed.add(pct)
                    allowed.add(round(pct, 0))

    return allowed


def validate_number_grounding(
    explanation_text: str,
    metrics_summary: List[Dict[str, Any]],
    weights_config: Optional[Dict[str, Any]] = None,
    tolerance: float = 0.5
) -> Dict[str, Any]:
    """
    Programmatically verify that every number mentioned in the LLM's explanation
    is grounded in the pre-computed metrics table.
    
    Returns:
        Dict with validation status, grounded count, hallucinated list, and audit verdict.
    """
    found_numbers = extract_numbers_from_text(explanation_text)
    allowed_numbers = build_allowed_number_set(metrics_summary, weights_config)

    grounded_numbers = []
    suspicious_numbers = []

    for num in found_numbers:
        # Check if number matches any allowed number within numeric tolerance
        is_grounded = any(abs(num - allowed) <= tolerance for allowed in allowed_numbers)
        if is_grounded:
            grounded_numbers.append(num)
        else:
            suspicious_numbers.append(num)

    is_clean = (len(suspicious_numbers) == 0)
    verdict = "PASSED: All numerical citations are strictly grounded." if is_clean else f"WARNING: {len(suspicious_numbers)} ungrounded or invented numbers detected."

    return {
        "is_valid": is_clean,
        "verdict": verdict,
        "total_numbers_checked": len(found_numbers),
        "grounded_numbers_count": len(grounded_numbers),
        "suspicious_numbers": suspicious_numbers,
        "suspicious_count": len(suspicious_numbers)
    }


def generate_ranking_explanation(
    ranked_metrics: List[Dict[str, Any]],
    weights_config: Dict[str, Any],
    llm_adapter: Optional[BaseLLMAdapter] = None
) -> Tuple[str, Dict[str, Any]]:
    """
    Invoke LLM reasoning layer to generate natural language analysis of pre-computed metrics,
    followed by automated anti-hallucination number validation.
    
    Args:
        ranked_metrics: List of club metric dictionaries (pre-aggregated, no student IDs)
        weights_config: The active scoring weights configuration
        llm_adapter: Optional LLM adapter instance
        
    Returns:
        Tuple of (explanation_markdown_text, validation_report)
    """
    if not llm_adapter:
        llm_adapter = get_llm_adapter()

    # Sanitize input: only pass aggregate club fields (Strict Privacy NFR)
    sanitized_table = []
    for row in ranked_metrics:
        sanitized_table.append({
            "rank": row.get("rank"),
            "club_name": row.get("club_name"),
            "composite_score": row.get("composite_score"),
            "reach_registrations": row.get("reach"),
            "activity_volume_events": row.get("activity_volume"),
            "planned_events": row.get("planned_events"),
            "attendance_rate_pct": row.get("attendance_rate_pct"),
            "engagement_quality_rating": row.get("engagement_quality"),
            "consistency_score": row.get("consistency_raw"),
            "data_status": row.get("data_status")
        })

    user_prompt = f"""Here is the deterministic metrics and ranking table for the evaluated clubs:

```json
{json.dumps(sanitized_table, indent=2)}
```

Scoring Weights Applied:
{json.dumps(weights_config.get("weights", {}), indent=2)}

Please write the executive performance narrative. Explain why the top clubs placed where they did, citing their exact attendance rates, ratings, and consistency scores from the table. Also call out any clubs operating under partial data."""

    messages = [{"role": "user", "content": user_prompt}]
    explanation_text = llm_adapter.call_text(messages, system_prompt=EXPLANATION_SYSTEM_PROMPT)

    # Perform automated number-grounding check
    validation_report = validate_number_grounding(explanation_text, ranked_metrics, weights_config)

    return explanation_text, validation_report
