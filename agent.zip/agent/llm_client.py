"""
Provider-Agnostic LLM Client for Smart Event Analytics Agent.
Supports Groq, Google Gemini, OpenRouter, and a Mock provider via .env configuration.
Written against a clean unified adapter interface so the orchestrator remains 100% provider-agnostic.
"""

import json
import os
import re
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Union
import requests
from dotenv import load_dotenv

# Load local environment variables
load_dotenv()


@dataclass
class ToolCall:
    """Standardized tool call representation across all LLM providers."""
    id: str
    name: str
    arguments: Dict[str, Any]


@dataclass
class LLMResponse:
    """Standardized LLM response object."""
    content: Optional[str]
    tool_calls: List[ToolCall] = field(default_factory=list)
    finish_reason: Optional[str] = None
    model: Optional[str] = None
    provider: Optional[str] = None


class BaseLLMAdapter:
    """Abstract base class for provider adapters."""
    def call_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        tool_choice: str = "auto"
    ) -> LLMResponse:
        raise NotImplementedError

    def call_text(
        self,
        messages: List[Dict[str, Any]],
        system_prompt: Optional[str] = None
    ) -> str:
        raise NotImplementedError


class GroqAdapter(BaseLLMAdapter):
    """Adapter for Groq Cloud API using the official Groq SDK."""
    def __init__(self):
        self.api_key = os.getenv("GROQ_API_KEY", "")
        self.model = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
        if not self.api_key or self.api_key.startswith("your_"):
            raise ValueError(
                "GROQ_API_KEY is not set or contains a placeholder. "
                "Please configure GROQ_API_KEY in your .env file."
            )
        try:
            from groq import Groq
            self.client = Groq(api_key=self.api_key)
        except ImportError:
            raise ImportError("Please install groq package: `pip install groq`")

    def call_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        tool_choice: str = "auto"
    ) -> LLMResponse:
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                tools=tools if tools else None,
                tool_choice=tool_choice if tools else None,
                temperature=0.1
            )
            choice = response.choices[0]
            message = choice.message
            content = message.content

            parsed_tool_calls = []
            if message.tool_calls:
                for tc in message.tool_calls:
                    args = tc.function.arguments
                    if isinstance(args, str):
                        try:
                            args = json.loads(args)
                        except Exception:
                            args = {}
                    parsed_tool_calls.append(ToolCall(
                        id=tc.id,
                        name=tc.function.name,
                        arguments=args
                    ))

            return LLMResponse(
                content=content,
                tool_calls=parsed_tool_calls,
                finish_reason=choice.finish_reason,
                model=self.model,
                provider="groq"
            )
        except Exception as e:
            raise RuntimeError(f"Groq API call failed: {str(e)}")

    def call_text(
        self,
        messages: List[Dict[str, Any]],
        system_prompt: Optional[str] = None
    ) -> str:
        call_msgs = []
        if system_prompt:
            call_msgs.append({"role": "system", "content": system_prompt})
        call_msgs.extend(messages)
        
        response = self.client.chat.completions.create(
            model=self.model,
            messages=call_msgs,
            temperature=0.2
        )
        return response.choices[0].message.content or ""


class OpenRouterAdapter(BaseLLMAdapter):
    """Adapter for OpenRouter API (OpenAI compatible)."""
    def __init__(self):
        self.api_key = os.getenv("OPENROUTER_API_KEY", "")
        self.model = os.getenv("OPENROUTER_MODEL", "meta-llama/llama-3.3-70b-instruct:free")
        self.base_url = "https://openrouter.ai/api/v1/chat/completions"
        if not self.api_key or self.api_key.startswith("your_"):
            raise ValueError("OPENROUTER_API_KEY is not set in .env")

    def call_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        tool_choice: str = "auto"
    ) -> LLMResponse:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost:8501",
            "X-Title": "Smart Event Analytics Agent"
        }
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0.1
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = tool_choice

        resp = requests.post(self.base_url, headers=headers, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        choice = data["choices"][0]
        msg = choice.get("message", {})
        content = msg.get("content")

        parsed_tool_calls = []
        if "tool_calls" in msg and msg["tool_calls"]:
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", {})
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                parsed_tool_calls.append(ToolCall(
                    id=tc.get("id", "call_1"),
                    name=fn.get("name", ""),
                    arguments=args
                ))

        return LLMResponse(
            content=content,
            tool_calls=parsed_tool_calls,
            finish_reason=choice.get("finish_reason"),
            model=self.model,
            provider="openrouter"
        )

    def call_text(
        self,
        messages: List[Dict[str, Any]],
        system_prompt: Optional[str] = None
    ) -> str:
        res = self.call_with_tools(
            ([{"role": "system", "content": system_prompt}] if system_prompt else []) + messages,
            tools=[]
        )
        return res.content or ""


class GeminiAdapter(BaseLLMAdapter):
    """Adapter for Google Gemini API via standard REST endpoint."""
    def __init__(self):
        self.api_key = os.getenv("GEMINI_API_KEY", "")
        self.model = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
        if not self.api_key or self.api_key.startswith("your_"):
            raise ValueError("GEMINI_API_KEY is not set in .env")

    def call_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        tool_choice: str = "auto"
    ) -> LLMResponse:
        # Converts standard tools format to Gemini REST format
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model}:generateContent?key={self.api_key}"
        
        # Convert messages
        contents = []
        for m in messages:
            role = "user" if m["role"] in ["user", "system"] else "model"
            contents.append({
                "role": role,
                "parts": [{"text": str(m["content"])}]
            })

        payload: Dict[str, Any] = {"contents": contents}
        resp = requests.post(url, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        
        try:
            cand = data["candidates"][0]
            text = cand["content"]["parts"][0]["text"]
            return LLMResponse(content=text, tool_calls=[], provider="gemini", model=self.model)
        except Exception as e:
            raise RuntimeError(f"Gemini API parse error: {e}")

    def call_text(
        self,
        messages: List[Dict[str, Any]],
        system_prompt: Optional[str] = None
    ) -> str:
        res = self.call_with_tools(
            ([{"role": "system", "content": system_prompt}] if system_prompt else []) + messages,
            tools=[]
        )
        return res.content or ""


class MockLLMAdapter(BaseLLMAdapter):
    """
    Deterministic Mock LLM adapter for fast automated testing and offline verification.
    Simulates tool-calling iterations and grounded explanations.
    """
    def __init__(self):
        self.call_count = 0

    def call_with_tools(
        self,
        messages: List[Dict[str, Any]],
        tools: List[Dict[str, Any]],
        tool_choice: str = "auto"
    ) -> LLMResponse:
        self.call_count += 1
        user_msg = ""
        for m in messages:
            if m["role"] == "user":
                user_msg = m["content"]

        # If user message has no date keywords or time period
        if "tell me which clubs performed best" in user_msg.lower() and not any(k in user_msg.lower() for k in ["semester", "2024", "month", "from", "last"]):
            return LLMResponse(
                content="Could you please specify the time period or semester (e.g., 'last semester' or '2024-01-15 to 2024-05-30') you want to analyze?",
                tool_calls=[],
                provider="mock"
            )

        # First turn: call get_events
        has_events_result = any(m.get("role") == "tool" and m.get("name") == "get_events" for m in messages)
        has_all_data = any(m.get("role") == "tool" and m.get("name") == "get_feedback" for m in messages)

        if not has_events_result:
            return LLMResponse(
                content="Fetching events conducted during last semester...",
                tool_calls=[
                    ToolCall(
                        id="call_mock_1",
                        name="get_events",
                        arguments={"start_date": "2024-01-15", "end_date": "2024-05-30", "category": "Technical"}
                    )
                ],
                provider="mock"
            )
        elif not has_all_data:
            # Second turn: request registrations, attendance, feedback, and club plans
            # Extract event ids from previous tool result
            event_ids = []
            for m in messages:
                if m.get("role") == "tool" and m.get("name") == "get_events":
                    try:
                        raw = json.loads(m["content"])
                        event_ids = [e["event_id"] for e in raw]
                    except Exception:
                        event_ids = ["EVT_001", "EVT_002", "EVT_003"]

            return LLMResponse(
                content="Fetching registration, attendance, feedback, and club planning targets...",
                tool_calls=[
                    ToolCall(id="call_mock_2", name="get_registrations", arguments={"event_ids": event_ids}),
                    ToolCall(id="call_mock_3", name="get_attendance", arguments={"event_ids": event_ids}),
                    ToolCall(id="call_mock_4", name="get_feedback", arguments={"event_ids": event_ids}),
                    ToolCall(id="call_mock_5", name="get_club_plans", arguments={})
                ],
                provider="mock"
            )
        else:
            return LLMResponse(
                content="All data retrieved successfully. Ready for deterministic calculation.",
                tool_calls=[],
                provider="mock"
            )

    def call_text(
        self,
        messages: List[Dict[str, Any]],
        system_prompt: Optional[str] = None
    ) -> str:
        # Returns a structured, grounded explanation based on the received JSON
        return (
            "### Qualitative Performance Analysis\n\n"
            "Based strictly on the computed metrics:\n"
            "1. **ACM Student Chapter** achieved the highest overall score with strong attendance and engagement.\n"
            "2. **AI & Machine Learning Club** demonstrated exceptional participant feedback.\n"
            "3. **Google Developer Student Club** maintained consistent execution across all planned events."
        )


def get_llm_adapter(provider: Optional[str] = None) -> BaseLLMAdapter:
    """
    Factory function returning the configured LLM adapter instance.
    Reads provider from LLM_PROVIDER env variable ('groq', 'gemini', 'openrouter', 'mock').
    """
    chosen_provider = (provider or os.getenv("LLM_PROVIDER", "groq")).strip().lower()

    if chosen_provider == "groq":
        return GroqAdapter()
    elif chosen_provider == "gemini":
        return GeminiAdapter()
    elif chosen_provider == "openrouter":
        return OpenRouterAdapter()
    elif chosen_provider in ["mock", "test"]:
        return MockLLMAdapter()
    else:
        raise ValueError(
            f"Unsupported LLM_PROVIDER '{chosen_provider}'. "
            f"Please choose one of: 'groq', 'gemini', 'openrouter', 'mock'."
        )
